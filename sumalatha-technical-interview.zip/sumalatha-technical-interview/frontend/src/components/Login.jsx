import React, {useState} from "react"
import axios from "axios";
import { Link } from "react-router-dom"


const Login = ({ setLoginUser}) => {


    const [ user, setUser] = useState({
        email:"",
        password:""
    })

    const handleChange = e => {
        const { name, value } = e.target
        setUser({
            ...user,
            [name]: value
        })
    }

    const handleLogin = () => {
        axios.post("http://localhost:5000/login", user)
        .then(res => {
            alert(res.data.message)
            setLoginUser(res.data.user)
        })
    }

    return (
        <div className="login" style={{width:"200px",height:"200px",border:"2px solid black",margin:"40px",padding:"10px"}}>
            <h1>Login</h1>
            <form onSubmit={handleLogin}>
            <input type="text" name="email" value={user.email} onChange={handleChange} placeholder="Enter your Email"></input>
            <input type="password" name="password" value={user.password} onChange={handleChange}  placeholder="Enter your Password" ></input>
<button type="submit">Login</button>            
</form>
<h6>if don't registered please click on </h6>
            <Link to="/register">Register</Link>
        </div>
    )
}

export default Login