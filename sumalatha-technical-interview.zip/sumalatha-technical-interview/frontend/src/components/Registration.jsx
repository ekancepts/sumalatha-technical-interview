import React, { useState } from "react"
import axios from "axios"
import { Link } from "react-router-dom"
const Register = () => {


    const [ user, setUser] = useState({
        name: "",
        email:"",
        password:"",
        reEnterPassword: ""
    })

    const handleChange = e => {
        const { name, value } = e.target
        setUser({
            ...user,
            [name]: value
        })
    }

    const handleSubmit = () => {
        const { name, email, password, reEnterPassword } = user
        if( name && email && password && (password === reEnterPassword)){
            axios.post("http://localhost:5000/postemp", user)
            .then( res => {
                alert(res.data.message)
                
            })
        } else {
            alert("invlid input")
        }
        
    }

    return (
        <div className="register" style={{width:"200px",height:"200px",border:"2px solid black",margin:"40px",padding:"10px"}}>
            {console.log("User", user)}
            <h1>Register</h1>
            <form onSubmit={handleSubmit}>
            <input type="text" name="name" value={user.name} placeholder="Your Name" onChange={ handleChange }></input>
            <input type="text" name="email" value={user.email} placeholder="Your Email" onChange={ handleChange }></input>
            <input type="password" name="password" value={user.password} placeholder="Your Password" onChange={ handleChange }></input>
            <input type="password" name="reEnterPassword" value={user.reEnterPassword} placeholder="Re-enter Password" onChange={ handleChange }></input>
           <button type="submit">Register</button>
           </form>
           <p>already have an account</p>
           <Link to="/login">login</Link>
           </div>
    )
}

export default Register