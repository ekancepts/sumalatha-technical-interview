

const express=require("express");
const empModel=require("./models/empmodel")
const loginModel=require("./models/loginmodel")
const app=express()
const connectDb=require("./src/db")
const port=5000;
app.use(express.json())

 app.post("/postemp",async(req,res)=>{
   connectDb()
   const postUser=new empModel(req.body)
   try{
      const saveduser=await postUser.save()
      res.status(201).send(saveduser)
    }catch(err){
   res.status(400).send(err)
   }
 })

 app.post("/login",async(req,res)=>{
   connectDb()
   const User=new loginModel(req.body)
   try{
      const saveduser=await User.save()
      res.status(201).send(saveduser)
    }catch(err){
   res.status(400).send(err)
   }
 })



 
 app.listen(port,()=>{
    console.log(`server is running on port ${port}`)

 })
