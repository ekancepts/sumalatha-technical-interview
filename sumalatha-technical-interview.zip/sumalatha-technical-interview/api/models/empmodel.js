const mongoose=require("mongoose")
const empModel=mongoose.model("emps",{
    name:{type:String},
    email:{type:String},
    password:{type:String}
})

module.exports=empModel;