const mongoose=require("mongoose")
const loginModel=mongoose.model("logs",{
    
    email:{type:String},
    password:{type:String}
})

module.exports=loginModel;